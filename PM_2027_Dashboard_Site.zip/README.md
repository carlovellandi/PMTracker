# Summer 2027 PM / APM Dashboard

This static site was generated from:
`Summer_2027_PM_APM_Targets_Carlo_Vellandi(1).xlsx`

Tracker source snapshot: 2026-08-16
Site generated: 2026-08-17

## Files
- `index.html` — dashboard UI and interaction logic
- `data.js` — the 30-program dataset. This is the file to replace when the recruiting data changes.

## Recommended free hosting: GitHub Pages
1. Create a new GitHub repository, e.g. `pm-2027-dashboard`.
2. If you use GitHub Free, make the repo **public** for GitHub Pages.
3. Upload `index.html` and `data.js` to the repository root.
4. In the repo, open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select `main` and `/ (root)`, then Save.
7. GitHub will give you a URL similar to `https://YOUR-USERNAME.github.io/pm-2027-dashboard/`.

## Alternative: Cloudflare Pages
Cloudflare Pages has a Free plan. You can use Direct Upload / drag-and-drop for this folder,
or connect a Git repository. A static HTML site requires no framework or build command.

## How future updates should work
The dashboard is intentionally split into code + data.

When recruiting facts change:
1. Ask ChatGPT to re-check the PM tracker / the specific programs that changed.
2. Upload your current `data.js` or this full site ZIP if needed.
3. ChatGPT can regenerate **only `data.js`**, leaving the design untouched.
4. Replace `data.js` in GitHub. GitHub Pages redeploys automatically.

Your personal recruiting status and notes are stored in your browser with localStorage, keyed by company + role.
Those notes survive normal `data.js` updates on the same browser. Use **Export my progress** as a backup or to move devices.

## Important limitation
This site is an interactive static dashboard, not a self-updating AI agent.
For automatic job monitoring, you can pair it with a recurring ChatGPT task that checks the target companies
and tells you when something changes. Then update `data.js` when needed.

A true AI chat embedded *inside* the webpage would require an API/backend and should never expose an API key
in client-side JavaScript.
